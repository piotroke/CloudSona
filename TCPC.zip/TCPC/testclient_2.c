/* tcpclient.c */
/*
 ============================================================================
 Name        : testclient_2.c
 Author      : Krzysztof Stankiewicz
 Version     :
 Copyright   : OKE Poland
 Description : test client for TCP to USB server
 ============================================================================
 */

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* indent -st -bap -bli0 -i4 -l79 -ncs -npcs -npsl -fca -lc79 -fc1 -ts4 x.c */

const char SET_LED_COLOR = 0x01;
const char LED_OFF = 0x02;
const char SET_BLINK_RATE = 0x03;
const char SET_LED_PATTERN = 0x04;
const char SET_AUDIO_SYNC_MODE = 0x05;
const char SET_DEFAULT_TIMEOUT = 0x06;
const char USER_COMMAND_1 = 0x07;
const char USER_COMMAND_2 = 0x08;
const char USER_COMMAND_3 = 0x09;
const char USER_COMMAND_4 = 0x0A;
const char USER_COMMAND_5 = 0x0B;
const char RESET_INITR = 0x0F;
const char opcode_lengths[] = {3, 2, 4, 4, 3, 4, 1, 1, 1, 1, 1, 1, 1, 1, 2};

int main()
{
	int sock;
	char send_data[5];
	char input_char;
	struct hostent *host;
	struct sockaddr_in server_addr;

	host = gethostbyname("192.168.1.128");

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("Socket");
		exit(1);
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(55555);
	server_addr.sin_addr = *((struct in_addr *)host->h_addr);
	bzero(&(server_addr.sin_zero), 8);

	if (connect(sock, (struct sockaddr *)&server_addr,
				sizeof(struct sockaddr)) == -1)
	{
		perror("Connect");
		exit(1);
	}

	while (1)
	{
		bzero(send_data, 5);

		input_char = getchar();
		switch (input_char)
		{
		case 'q':
			send_data[0] = SET_LED_COLOR;
			send_data[1] = 0xF0;
			send_data[2] = 0x07;
			break;
		case 'w':
			send_data[0] = SET_LED_COLOR;
			send_data[1] = 0x41;
			send_data[2] = 0x01;
			break;
		case 'e':
			send_data[0] = LED_OFF;
			send_data[1] = 0x80;
			break;
		case 'r':
			send_data[0] = SET_BLINK_RATE;
			send_data[1] = 0x80;
			send_data[2] = 0x81;
			send_data[3] = 0x02;
			break;
		case 't':
			send_data[0] = SET_AUDIO_SYNC_MODE;
			send_data[1] = 0x01;
			send_data[2] = 0x00;
			break;
		case 'y':
			send_data[0] = SET_AUDIO_SYNC_MODE;
			send_data[1] = 0x01;
			send_data[2] = 0x02;
			break;
		case 'u':
			send_data[0] = SET_DEFAULT_TIMEOUT;
			send_data[1] = 0x80;
			send_data[2] = 0x20;
			send_data[3] = 0x20;
			break;
		case 'i':
			send_data[0] = USER_COMMAND_1;
			break;
		case 'o':
			send_data[0] = USER_COMMAND_2;
			break;
		case 'p':
			send_data[0] = USER_COMMAND_3;
			break;
		default:
			continue;
		}
		send(sock, send_data, /*opcode_lengths[send_data[0]]*/5, 0);
	}
	return 0;
}
