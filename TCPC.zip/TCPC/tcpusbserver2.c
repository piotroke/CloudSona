/* 
   ============================================================================
   Name : tcpusbserver_2.c Author : Krzysztof Stankiewicz Version : Copyright :
   OKE Poland Description : TCP to USB server
   ============================================================================ */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

/* declarations */
void serve_client(int, struct sockaddr_in);
void handlePayload(char *data);
void error(const char *msg);

int main()
{
	int pid;					// for fork
	int listenfd, connfd;
	socklen_t clilen;
	struct sockaddr_in server_addr, client_addr;
	char recv_data[5];
	int bytes_recieved, true = 1;
	int sin_size;


	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if (listenfd < 0)
		error("Error creating socket");
	if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &true, sizeof(int)) ==
		-1)
		error("Error on setsockopt");
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(55555);
	server_addr.sin_addr.s_addr = INADDR_ANY;
	bzero(&(server_addr.sin_zero), 8);

	if (bind(listenfd, (struct sockaddr *)&server_addr,
			 sizeof(struct sockaddr)) < 0)
		error("Error on binding");
	if (listen(listenfd, 5) == -1)
		error("Error on Listen");

	clilen = sizeof(struct sockaddr_in);

	printf("Waiting for client on port 55555\n");
	fflush(stdout);

	while (1)
	{
		connfd = accept(listenfd, (struct sockaddr *)&client_addr, &clilen);
		if (connfd < 0)
			error("Error on accept");
		pid = fork();
		if (pid < 0)
			error("Error on fork");
		if (pid == 0)
		{
			close(listenfd);	// not needed in this process
			serve_client(connfd, client_addr);
		}
		else
			close(connfd);		// and reopen again in next iteration


	}							// while
	// the below is never reached
	close(listenfd);
	return 0;
}





/******** serve_client() *********************
 Handles all communication and data processing
 after a connection is established
 *****************************************/
void serve_client(int sock, struct sockaddr_in client)	// own thread
{
	char recv_data[5];
	int count;
	char client_desc[25];

	sprintf(client_desc, "(%s:%d)",
			inet_ntoa(client.sin_addr), ntohs(client.sin_port));

	printf("Client connected: %s\n", client_desc);

	while (1)
	{
		// bzero(recv_data,5);
		count = read(sock, recv_data, 5);
		if (count < 0)
		{
			printf("Client dissconnected: %s\n", client_desc);
			exit(0);
		}
		else if (count == 0)
		{
			printf("Error on socket read\n");
			exit(0);
		}
		handlePayload(recv_data);
	}
}




const char *opcode_names[] = {
	"(nothing)",
	"SET_LED_COLOR",
	"LED_OFF",
	"SET_BLINK_RATE",
	"SET_LED_PATTERN",
	"SET_AUDIO_SYNC_MODE",
	"SET_DEFAULT_TIMEOUT",
	"USER_COMMAND_1",
	"USER_COMMAND_2",
	"USER_COMMAND_3",
	"USER_COMMAND_4",
	"USER_COMMAND_5",
	"-",
	"-",
	"-",
	"RESET_INITR"
};

/******** serve_client() *********************
 Translate Payload to currently supported format if necessary and pass it to USB device
 *****************************************/
void handlePayload(char *data) {
char group_name[20];

if(data[1] & 0x80) strcpy(group_name, "All Groups");
else
	sprintf(group_name, "Group %d", (data[1] & 0x03));
printf("%s, %s, %X %X %X\n",
		   opcode_names[data[0]], group_name, data[2], data[3], data[4]);
}




void error(const char *msg)
{
	perror(msg); exit(1);
}
